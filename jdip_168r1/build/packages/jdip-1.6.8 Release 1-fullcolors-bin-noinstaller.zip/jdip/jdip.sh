#!/bin/sh
java -Xss1024K -Xms64m -Xmx192m -jar jdip.jar
